package com.example.appdereceita

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
