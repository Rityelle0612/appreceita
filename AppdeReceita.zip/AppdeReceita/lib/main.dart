import 'package:appdereceita/pages/home_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
      const MaterialApp(
        home: homePage(),
      )
  );
}
